"Bachelors Of Domination" - Risky Developments

Launch Guide for Windows systems:
To run the .jar Java MUST be installed.
Once you have downloaded BoD.zip it is neccessary to extract the file to launch the program.

Launch Guide for Unix systems:
To run the .jar Java MUST be installed.

User Manual: http://www.riskydevelopments.co.uk/documents/GameManualPDF.pdf