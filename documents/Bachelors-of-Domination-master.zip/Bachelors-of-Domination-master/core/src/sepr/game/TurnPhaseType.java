package sepr.game;

/**
 * the three possible turn phases
 */
public enum TurnPhaseType {
    REINFORCEMENT, ATTACK, MOVEMENT
}
